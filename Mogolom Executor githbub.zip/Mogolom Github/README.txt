Note:
This executor is shi bc is my first exec :DDD

Dont Do it bigger!

Nota:
Este executor es una mierda por que es mi primer executor

No agrandes la ventana!


